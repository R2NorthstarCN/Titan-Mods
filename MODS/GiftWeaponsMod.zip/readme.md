<!--
 * @Author: HK560
 * @Date: 2021-12-26 10:13:25
 * @LastEditTime: 2021-12-26 10:14:46
 * @LastEditors: HK560
 * @Description:
 * @FilePath: \NorthStarCN_WIKIi:\Desktop\Gift\readme.md
 * My Blog: https://blog.hk560.top
-->
Gift Mod
--
Basically most of it was inspired by Icepick's method of spawning in weapons, but now you'll be able to gift everyone or certain players on your server certain weapons/tacticals/abilites.

There are two commands in this mod:
```
gift <weaponId> <playerId>
mod <modId>
```
Typing gift by itself will print out every player's name + their playerId.
You can lookup weaponIds by typing give and pressing Tab to cycle through the multiple weapon IDS.
Typing mod by itself will print out every single weapon mods available. Do keep in mind that some weapon mods conflict with certain weapons and will result in a crash. (Ex. CARs can't have variable scope or ricochet mods. Every weapon also cannot have more than 4 mods.)

Some examples:
gift mp_weapon_sniper all will remove their primary weapon and replace it with a Kraber.
gift mp_titanweapon_leadwall 2 will remove the player with an ID of 2's primary weapon and replace it with a Leadwall.
mod pas_run_and_gun will add/remove the Gunrunner mod on your weapon.

Notes:
- Weapons don't persist after death.
- Beware that some weapon IDs are developer weapons and could result in a crash if misused.

By:[ASIA] x3Karma from NorthStar discord